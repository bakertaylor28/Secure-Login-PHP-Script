<?php
/**
 * These are the database login details
 */  
define("HOST", "localhost");     // The host you want to connect to.
define("USER", "id3263427_sec_user");    // The database username. 
define("PASSWORD", "Itudmenif1!Itudmenif1!");    // The database password. 
define("DATABASE", "id3263427_secure_login");    // The database name.
 
define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");
 
define("SECURE", TRUE);    // FALSE- FOR DEVELOPMENT ONLY!!!!
?>